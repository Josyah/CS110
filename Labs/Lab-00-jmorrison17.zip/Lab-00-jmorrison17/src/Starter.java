// YOUR NAME HERE
// Lab-00
// Starter.java

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Magic.println("Welcome to CS110!");
		
		Magic.println("Please enter an integer.");
		int myInt1 = Magic.nextInt();
		Magic.println("Please enter a second integer.");
		int myInt2 = Magic.nextInt();
		Magic.println("Please enter a third integer.");
		int myInt3 = Magic.nextInt();
		
		int mySum = myInt1 + myInt2 + myInt3;
		Magic.println("The total is...");
		Magic.println(mySum);

	}

}
