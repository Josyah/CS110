// Josyah Morrison
// Lab-04
// StartAPlus.java

public class StartAPlus {
	
}